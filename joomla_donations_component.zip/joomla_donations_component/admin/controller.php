<?php
defined('_JEXEC') or die('Restricted access');

class PesapalController extends JControllerLegacy
{
    /**
     * The default view for the display method.
     *
     * @var string
     * @since 12.2
     */
    protected $default_view = 'donations';

}

