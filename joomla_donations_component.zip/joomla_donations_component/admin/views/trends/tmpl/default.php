<?php
defined('_JEXEC') or die;
?>

    <div id="j-sidebar-container" class="span2">
        <?php echo $this->sidebar = JHtmlSidebar::render(); ?>
    </div>
    <div id="j-main-container" class="span10">
        <div id="container" class="span6" style="height: 400px;"></div>
        <div id="container_pie" class="span6" style="height: 400px;"></div>
    </div>
