<div id="app"></div>

<input type="hidden" value="<?php echo $this->pay_type ?>" id="pay_type"/>
<input type="hidden" value="<?php echo $this->address_fields ?>" id="address_fields"/>


