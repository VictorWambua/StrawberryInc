var Form = React.createClass({
    render : function () {
        return(
            <div id="formContainer">
                <h1>Donation Form</h1>
            </div>
        )

    }

});